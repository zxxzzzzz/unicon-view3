import { defineComponent, ref, mergeProps, unref, withCtx, createVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent } from "vue/server-renderer";
import { Tabs, TabPane, Table } from "ant-design-vue";
import { b as block0 } from "../main.mjs";
import "vue-router";
import "@intlify/shared";
import "@intlify/core-base";
import "@vue/devtools-api";
import "@intlify/vue-devtools";
import "@vueuse/head";
import "@vueuse/core";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const state = ref({
      currentTabName: "系统"
    });
    const alarmColumns = [
      {
        title: "devId",
        dataIndex: "devId",
        key: "devId"
      },
      {
        title: "devName",
        dataIndex: "devName",
        key: "devName"
      },
      {
        title: "alarmLevel",
        dataIndex: "alarmLevel",
        key: "alarmLevel"
      },
      {
        title: "alarmModule",
        dataIndex: "alarmModule",
        key: "alarmModule"
      },
      {
        title: "alarmDesc",
        dataIndex: "alarmDesc",
        key: "alarmDesc"
      },
      {
        title: "alarmState",
        dataIndex: "alarmState",
        key: "alarmState"
      },
      {
        title: "alarmTime",
        dataIndex: "alarmTime",
        key: "alarmTime"
      },
      {
        title: "confirmTime",
        dataIndex: "confirmTime",
        key: "confirmTime"
      },
      {
        title: "clearTime",
        dataIndex: "clearTime",
        key: "clearTime"
      }
    ];
    const systemColumns = [
      {
        title: "alarmModule",
        dataIndex: "alarmModule",
        key: "alarmModule"
      },
      {
        title: "alarmDesc",
        dataIndex: "alarmDesc",
        key: "alarmDesc"
      },
      {
        title: "alarmTime",
        dataIndex: "alarmTime",
        key: "alarmTime"
      },
      {
        title: "alarmModule",
        dataIndex: "alarmModule",
        key: "alarmModule"
      },
      {
        title: "clearTime",
        dataIndex: "clearTime",
        key: "clearTime"
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-2" }, _attrs))}>`);
      _push(ssrRenderComponent(unref(Tabs), {
        activeKey: state.value.currentTabName,
        "onUpdate:activeKey": ($event) => state.value.currentTabName = $event
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(TabPane), {
              key: "系统",
              tab: "系统"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(Table), { columns: alarmColumns }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(Table), { columns: alarmColumns })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(TabPane), {
              key: "日志",
              tab: "日志",
              "force-render": ""
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(Table), { columns: systemColumns }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(Table), { columns: systemColumns })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(TabPane), {
                key: "系统",
                tab: "系统"
              }, {
                default: withCtx(() => [
                  createVNode(unref(Table), { columns: alarmColumns })
                ]),
                _: 1
              }),
              createVNode(unref(TabPane), {
                key: "日志",
                tab: "日志",
                "force-render": ""
              }, {
                default: withCtx(() => [
                  createVNode(unref(Table), { columns: systemColumns })
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
});
if (typeof block0 === "function")
  block0(_sfc_main);
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/system/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
