import { defineComponent, ref, mergeProps, unref, withCtx, createTextVNode, openBlock, createBlock, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderClass, ssrRenderComponent } from "vue/server-renderer";
import { Input, Tabs, TabPane } from "ant-design-vue";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "panel",
  __ssrInlineRender: true,
  setup(__props) {
    const state = ref({
      currentTabName: 0,
      currentPortTabName: 0,
      currentFrequencyTabName: 0,
      currentTimeTabName: 0
      /* 输入 */
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex" }, _attrs))}><div class="w-10rem mr-2rem"><div class="${ssrRenderClass([unref(state).currentTabName === 0 ? "text-white" : "", "py-2rem text-center bg-blue border border-solid border-blue-9"])}">网元 </div><div class="${ssrRenderClass([unref(state).currentTabName === 1 ? "text-white" : "", "py-2rem text-center bg-blue border border-solid border-blue-9"])}">板卡 </div><div class="${ssrRenderClass([unref(state).currentTabName === 2 ? "text-white" : "", "py-2rem text-center bg-blue border border-solid border-blue-9"])}">端口 </div><div class="${ssrRenderClass([unref(state).currentTabName === 3 ? "text-white" : "", "py-2rem text-center bg-blue border border-solid border-blue-9"])}">频率 </div><div class="${ssrRenderClass([unref(state).currentTabName === 4 ? "text-white" : "", "py-2rem text-center bg-blue border border-solid border-blue-9"])}">时间 </div></div><div class="flex-1">`);
      if (unref(state).currentTabName === 0) {
        _push(`<div><div class="flex"><div class="w-10rem">NodeId</div><div>`);
        _push(ssrRenderComponent(unref(Input), null, null, _parent));
        _push(`</div></div><div class="flex"><div class="w-10rem">Duty</div><div>`);
        _push(ssrRenderComponent(unref(Input), null, null, _parent));
        _push(`</div></div><div class="flex"><div class="w-10rem">state</div><div>`);
        _push(ssrRenderComponent(unref(Input), null, null, _parent));
        _push(`</div></div><div class="flex"><div class="w-10rem">ClockClass</div><div>`);
        _push(ssrRenderComponent(unref(Input), null, null, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(state).currentTabName === 1) {
        _push(`<div><div class="flex"><div class="w-10rem">P</div><div>`);
        _push(ssrRenderComponent(unref(Input), null, null, _parent));
        _push(`</div></div><div class="flex"><div class="w-10rem">I</div><div>`);
        _push(ssrRenderComponent(unref(Input), null, null, _parent));
        _push(`</div></div><div class="flex"><div class="w-10rem">D</div><div>`);
        _push(ssrRenderComponent(unref(Input), null, null, _parent));
        _push(`</div></div><div class="flex"><div class="w-10rem">FiberConfig</div><div>`);
        _push(ssrRenderComponent(unref(Input), null, null, _parent));
        _push(`</div></div><div class="flex"><div class="w-10rem">setValue</div><div>`);
        _push(ssrRenderComponent(unref(Input), null, null, _parent));
        _push(`</div></div><div class="flex"><div class="w-10rem">clockSource</div><div>`);
        _push(ssrRenderComponent(unref(Input), null, null, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(state).currentTabName === 2) {
        _push(`<div>`);
        _push(ssrRenderComponent(unref(Tabs), {
          activeKey: unref(state).currentPortTabName,
          "onUpdate:activeKey": ($event) => unref(state).currentPortTabName = $event
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(unref(TabPane), {
                key: 0,
                tab: "SMA_1"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`Content of Tab Pane 1`);
                  } else {
                    return [
                      createTextVNode("Content of Tab Pane 1")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(unref(TabPane), {
                key: 1,
                tab: "SMA_2",
                "force-render": ""
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`Content of Tab Pane 2`);
                  } else {
                    return [
                      createTextVNode("Content of Tab Pane 2")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(unref(TabPane), {
                key: 2,
                tab: "SMA_3"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`Content of Tab Pane 3`);
                  } else {
                    return [
                      createTextVNode("Content of Tab Pane 3")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              return [
                (openBlock(), createBlock(unref(TabPane), {
                  key: 0,
                  tab: "SMA_1"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Content of Tab Pane 1")
                  ]),
                  _: 1
                })),
                (openBlock(), createBlock(unref(TabPane), {
                  key: 1,
                  tab: "SMA_2",
                  "force-render": ""
                }, {
                  default: withCtx(() => [
                    createTextVNode("Content of Tab Pane 2")
                  ]),
                  _: 1
                })),
                (openBlock(), createBlock(unref(TabPane), {
                  key: 2,
                  tab: "SMA_3"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Content of Tab Pane 3")
                  ]),
                  _: 1
                }))
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(state).currentTabName === 3) {
        _push(`<div>`);
        _push(ssrRenderComponent(unref(Tabs), {
          activeKey: unref(state).currentFrequencyTabName,
          "onUpdate:activeKey": ($event) => unref(state).currentFrequencyTabName = $event
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(unref(TabPane), {
                key: 0,
                tab: "输入"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`Content of Tab Pane 1`);
                  } else {
                    return [
                      createTextVNode("Content of Tab Pane 1")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(unref(TabPane), {
                key: 1,
                tab: "输出",
                "force-render": ""
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`Content of Tab Pane 2`);
                  } else {
                    return [
                      createTextVNode("Content of Tab Pane 2")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              return [
                (openBlock(), createBlock(unref(TabPane), {
                  key: 0,
                  tab: "输入"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Content of Tab Pane 1")
                  ]),
                  _: 1
                })),
                (openBlock(), createBlock(unref(TabPane), {
                  key: 1,
                  tab: "输出",
                  "force-render": ""
                }, {
                  default: withCtx(() => [
                    createTextVNode("Content of Tab Pane 2")
                  ]),
                  _: 1
                }))
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(state).currentTabName === 4) {
        _push(`<div>`);
        _push(ssrRenderComponent(unref(Tabs), {
          activeKey: unref(state).currentTimeTabName,
          "onUpdate:activeKey": ($event) => unref(state).currentTimeTabName = $event
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(unref(TabPane), {
                key: 0,
                tab: "输入"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`Content of Tab Pane 1`);
                  } else {
                    return [
                      createTextVNode("Content of Tab Pane 1")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(unref(TabPane), {
                key: 1,
                tab: "输出",
                "force-render": ""
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`Content of Tab Pane 2`);
                  } else {
                    return [
                      createTextVNode("Content of Tab Pane 2")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(unref(TabPane), {
                key: 2,
                tab: "输出1"
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`Content of Tab Pane 3`);
                  } else {
                    return [
                      createTextVNode("Content of Tab Pane 3")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              return [
                (openBlock(), createBlock(unref(TabPane), {
                  key: 0,
                  tab: "输入"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Content of Tab Pane 1")
                  ]),
                  _: 1
                })),
                (openBlock(), createBlock(unref(TabPane), {
                  key: 1,
                  tab: "输出",
                  "force-render": ""
                }, {
                  default: withCtx(() => [
                    createTextVNode("Content of Tab Pane 2")
                  ]),
                  _: 1
                })),
                (openBlock(), createBlock(unref(TabPane), {
                  key: 2,
                  tab: "输出1"
                }, {
                  default: withCtx(() => [
                    createTextVNode("Content of Tab Pane 3")
                  ]),
                  _: 1
                }))
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/config/panel.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
