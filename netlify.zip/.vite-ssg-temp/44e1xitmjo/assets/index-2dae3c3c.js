import { defineComponent, ref, mergeProps, unref, withCtx, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderClass, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1, o as openWindow } from "./utils-c995a5aa.js";
import { Button } from "ant-design-vue";
import { b as block0 } from "../main.mjs";
import "cytoscape";
import "cytoscape-edgehandles";
import "cytoscape-popper";
import "@intlify/shared";
import "@intlify/core-base";
import "@vue/devtools-api";
import "@intlify/vue-devtools";
import "nprogress";
import "pinia";
import "vite-ssg";
import "vue-router";
import "@vueuse/head";
import "@vueuse/core";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const nodeTypeList = [
      { value: 0, label: "节点1" },
      { value: 1, label: "节点2" }
    ];
    const edgeTypeList = [
      { value: 0, label: "链路1" },
      { value: 1, label: "链路2" }
    ];
    const state = ref({
      nodes: [{
        position: { x: 100, y: 100 },
        data: {
          id: "123"
        }
      }, {
        position: { x: 200, y: 300 },
        data: {
          id: "1234"
        }
      }],
      edges: [],
      currentNodeType: 0,
      currentEdgeType: 0
      /* a */
    });
    const handleCreateNode = () => {
      const node = {
        position: { x: 100, y: 100 },
        data: {
          id: (/* @__PURE__ */ new Date()).valueOf().toString()
        }
      };
      state.value.nodes = [...state.value.nodes, node];
    };
    const handleDoubleClick = () => {
      openWindow("/config/panel");
      console.log("dbbbb");
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex h-full" }, _attrs))}><div class="h-full relative overflow-auto flex-1"><div class="absolute left-4 z-10">`);
      _push(ssrRenderComponent(unref(Button), {
        type: "primary",
        class: "mt-[1rem] bg-blue",
        onClick: handleCreateNode
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`新建节点`);
          } else {
            return [
              createTextVNode("新建节点")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="h-[calc(100%-10rem)]">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        nodes: state.value.nodes,
        edges: state.value.edges,
        onDblclick: handleDoubleClick
      }, null, _parent));
      _push(`</div><div><div class="flex items-center"><div>网元添加</div><!--[-->`);
      ssrRenderList(nodeTypeList, (node) => {
        _push(`<div class="${ssrRenderClass([state.value.currentNodeType === node.value ? "bg-blue" : "", "w-5rem h-5rem border"])}">${ssrInterpolate(node.label)}</div>`);
      });
      _push(`<!--]--></div><div class="flex items-center"><div>链路添加</div><!--[-->`);
      ssrRenderList(edgeTypeList, (edge) => {
        _push(`<div class="${ssrRenderClass([state.value.currentEdgeType === edge.value ? "bg-blue" : "", "w-5rem h-5rem border"])}">${ssrInterpolate(edge.label)}</div>`);
      });
      _push(`<!--]--></div></div></div><div class="w-20rem flex flex-col"><div>仿真结果</div><div class="border border-solid border-gray flex-1"></div></div></div>`);
    };
  }
});
if (typeof block0 === "function")
  block0(_sfc_main);
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/topology/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
