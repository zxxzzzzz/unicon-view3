import { defineComponent, ref, mergeProps, unref, withCtx, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent } from "vue/server-renderer";
import { Input, Button } from "ant-design-vue";
import { useRouter } from "vue-router";
import { b as block0 } from "../main.mjs";
import "@intlify/shared";
import "@intlify/core-base";
import "@vue/devtools-api";
import "@intlify/vue-devtools";
import "nprogress";
import "pinia";
import "vite-ssg";
import "@vueuse/head";
import "@vueuse/core";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const router = useRouter();
    const state = ref({
      username: "",
      password: ""
    });
    const handleRegistry = () => {
      router.push({ path: "/config" });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex h-[100vh]" }, _attrs))}><div class="w-full flex flex-col justify-center items-center"><div class="flex mb-[1rem]"><div class="w-[6rem]">用户名</div>`);
      _push(ssrRenderComponent(unref(Input), {
        class: "w-[20rem]",
        value: state.value.username,
        "onUpdate:value": ($event) => state.value.username = $event
      }, null, _parent));
      _push(`</div><div class="flex"><div class="w-[6rem]">密码</div>`);
      _push(ssrRenderComponent(unref(Input), {
        class: "w-[20rem]",
        value: state.value.password,
        "onUpdate:value": ($event) => state.value.password = $event,
        type: "password"
      }, null, _parent));
      _push(`</div><div class="mt-[1rem] flex justify-end ml-20rem"><div>`);
      _push(ssrRenderComponent(unref(Button), { onClick: handleRegistry }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`注册`);
          } else {
            return [
              createTextVNode("注册")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div>`);
    };
  }
});
if (typeof block0 === "function")
  block0(_sfc_main);
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/registry/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
