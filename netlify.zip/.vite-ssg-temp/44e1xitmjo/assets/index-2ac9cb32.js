import { defineComponent, ref, mergeProps, unref, withCtx, createTextVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent } from "vue/server-renderer";
import { _ as _sfc_main$1, o as openWindow } from "./utils-c995a5aa.js";
import { Button } from "ant-design-vue";
import { b as block0 } from "../main.mjs";
import "cytoscape";
import "cytoscape-edgehandles";
import "cytoscape-popper";
import "@intlify/shared";
import "@intlify/core-base";
import "@vue/devtools-api";
import "@intlify/vue-devtools";
import "nprogress";
import "pinia";
import "vite-ssg";
import "vue-router";
import "@vueuse/head";
import "@vueuse/core";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const state = ref({
      nodes: [{
        position: { x: 100, y: 100 },
        data: {
          id: "123"
        }
      }, {
        position: { x: 200, y: 300 },
        data: {
          id: "1234"
        }
      }],
      edges: [],
      currentNodeType: 0,
      currentEdgeType: 0
      /* a */
    });
    const handleCreateNode = () => {
      const node = {
        position: { x: 100, y: 100 },
        data: {
          id: "123456"
        }
      };
      state.value.nodes = [...state.value.nodes, node];
    };
    const handleDoubleClick = () => {
      openWindow("/config/panel");
      console.log("dbbbb");
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex h-full" }, _attrs))}><div class="h-full relative overflow-auto flex-1"><div class="absolute left-4 z-10">`);
      _push(ssrRenderComponent(unref(Button), {
        type: "primary",
        class: "mt-[1rem] bg-blue",
        onClick: handleCreateNode
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`新建节点`);
          } else {
            return [
              createTextVNode("新建节点")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="h-[calc(100%-2px)]">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        nodes: state.value.nodes,
        edges: state.value.edges,
        onDblclick: handleDoubleClick
      }, null, _parent));
      _push(`</div></div><div><div class="w-20rem"><div class="bg-gray p-2"><div class="flex items-center"><div>时间</div><div class="h-1px bg-white flex-1"></div></div><div class="flex"><div><div><div>运行状态</div></div><div><div>MTIE</div></div><div><div>性能测量</div></div></div><div class="flex-1"><div class="ml-2 h-5rem bg-white"></div></div></div></div></div><div class="w-20rem mt-4"><div class="bg-gray p-2"><div class="flex items-center"><div>时间</div><div class="h-1px bg-white flex-1"></div></div><div class="flex"><div><div><div>运行状态</div></div><div><div>MTIE</div></div><div><div>性能测量</div></div></div><div class="flex-1"><div class="ml-2 h-5rem bg-white"></div></div></div></div></div></div></div>`);
    };
  }
});
if (typeof block0 === "function")
  block0(_sfc_main);
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/performance/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
