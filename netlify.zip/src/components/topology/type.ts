interface CNode {
  
}