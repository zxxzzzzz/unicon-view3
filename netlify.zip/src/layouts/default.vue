<template>
  <main>
    <RouterView />
    <!-- <TheFooter />
    <div mx-auto mt-5 text-center text-sm opacity-50>
      [Default Layout]
    </div> -->
  </main>
</template>
